class DropFluffysTable < ActiveRecord::Migration
  def change
  end
end
